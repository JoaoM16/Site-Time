document.addEventListener('DOMContentLoaded', function() {  
  const usuario = JSON.parse(localStorage.getItem('usuario'));  
  const perfilDiv = document.getElementById('perfil');  
  const btnCadastro = document.getElementById('btnCadastro');  

  if (!usuario) {  
      // Se não houver usuário cadastrado, exibe o botão de cadastro  
      btnCadastro.style.display = 'block'; // Mostra o botão  
      btnCadastro.addEventListener('click', function() {  
          // Redireciona para a página de cadastro ao clicar no botão  
          window.location.href = 'socio.html'; // Altere para o caminho correto da sua página de cadastro  
      });  
  } else {  
      // Se o usuário estiver cadastrado, exibe as informações  
      perfilDiv.innerHTML = `  
          <p><strong>Nome:</strong> ${usuario.nome}</p>  
          <p><strong>Data de Nascimento:</strong> ${usuario.data}</p>  
          <p><strong>CPF:</strong> ${usuario.cpf}</p>  
          <p><strong>Nome do Pai:</strong> ${usuario.pai}</p>  
          <p><strong>Nome da Mãe:</strong> ${usuario.mae}</p>  
          <p><strong>Telefone:</strong> ${usuario.telefone}</p>  
          <p><strong>E-mail:</strong> ${usuario.email}</p>  
          <p><strong>Cidade:</strong> ${usuario.cidade}</p>  
          <p><strong>Estado:</strong> ${usuario.estado}</p>  
          <p><strong>Bairro:</strong> ${usuario.bairro}</p>  
          <p><strong>Rua:</strong> ${usuario.rua}</p>  
          <p><strong>CEP:</strong> ${usuario.cep}</p>  
          <p><strong>Número:</strong> ${usuario.numero}</p>  
          <p><strong>Plano Desejado:</strong> ${usuario.plano}</p>  
      `;  
  }  
}); 