let currentSlide = 0;  
  const slides = document.querySelectorAll('.slide');  
  const totalSlides = slides.length;  

function showSlide(index) {  
  slides.forEach((slide) => {  
    slide.style.display = 'none'; // Esconde todos os slides  
    });  
    slides[index].style.display = 'block'; // Mostra o slide atual  
}  

function nextSlide() {  
  currentSlide = (currentSlide + 1) % totalSlides; // Avança para o próximo slide  
  showSlide(currentSlide);  
}  

// Inicia o slideshow  
showSlide(currentSlide);  
setInterval(nextSlide, 2000); // Muda de slide a cada 3 segundos