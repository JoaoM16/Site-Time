document.addEventListener('DOMContentLoaded', function() {  
  const form = document.getElementById('cadastroForm');  

  form.addEventListener('submit', function(event) {  
      event.preventDefault(); // Impede o envio padrão do formulário  

      // Coleta os dados do formulário  
      const formData = {  
          nome: form.nome.value,  
          data: form.data.value,  
          cpf: form.cpf.value,  
          pai: form.pai.value,  
          mae: form.mae.value,  
          telefone: form.telefone.value,  
          email: form.email.value,  
          cidade: form.cidade.value,  
          estado: form.estado.value,  
          bairro: form.bairro.value,  
          rua: form.rua.value,  
          cep: form.cep.value,  
          numero: form.numero.value,  
          plano: form.plano.value  
      };  

      // Armazena os dados no localStorage  
      localStorage.setItem('usuario', JSON.stringify(formData));  

      // Redireciona para a página do perfil  
      window.location.href = 'perfil.html'; // Altere para o caminho correto da sua página de perfil  
  });  
});

let currentSlide = 0;  
        const slides = document.querySelectorAll('.slide');  
        const totalSlides = slides.length;  

        function showSlide(index) {  
            slides.forEach((slide) => {  
                slide.style.display = 'none'; // Esconde todos os slides  
            });  
            slides[index].style.display = 'block'; // Mostra o slide atual  
        }  

        function nextSlide() {  
            currentSlide = (currentSlide + 1) % totalSlides; // Avança para o próximo slide  
            showSlide(currentSlide);  
        }  

        // Inicia o slideshow  
        showSlide(currentSlide);  
        setInterval(nextSlide, 2000); // Muda de slide a cada 3 segundos

